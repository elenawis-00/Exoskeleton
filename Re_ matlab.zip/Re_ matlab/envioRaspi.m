function [] = envioRaspi(coef_motor1, coef_motor2, t_total)

% Conecto al servidor en Raspberry Pi
tcpObj = tcpclient('192.168.0.101', 8081);

%Creo un mensaje único y completo
delimiter = ';'; % Delimitador único
mensaje = sprintf('%s%s%s', num2str(coef_motor1), delimiter, num2str(coef_motor2), delimiter, num2str(t_total));



%Envío el mensaje
fwrite(tcpObj, mensaje);

end