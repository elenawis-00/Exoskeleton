function [coef_motor1, coef_motor2, t_total, p001, p002] = calc_trajectory(tobillo_x, tobillo_y,l1, l2, g, m1, m2, OA, AB, BC, OC)

    % Determination of the Theta1 and Theta2 angles of the EXOLEG (in degrees), according to a trajectory imposed at point P (end of the robot)
    
    [n, m] = size(tobillo_x);

    t_total = m/10;
    
    v = 0;
    % t = 0.1:0.1:t_total;
    t = 0.1:0.1:t_total;
    t = t(:);
    
    tibia_pos_x = tobillo_x;
    tibia_pos_y = tobillo_y;

    [rows, cols] = size(tibia_pos_x);
    points_num = cols;

    time_interval = t_total/points_num;
    
    t1 = time_interval:time_interval:t_total;
    tibia_x = polyfit(t,tibia_pos_x,10);
    tibia_x_fit = polyval(tibia_x,t1);
    tibia_y = polyfit(t,tibia_pos_y,10);
    tibia_y_fit = polyval(tibia_y,t1);
    
    vPx = zeros(1, cols);            % Array storing the x coordinates of the desired trajectory
    vPy = zeros(1,cols);            % Array storing the y coordinates of the desired trajectory
    X = zeros(1,cols);
    Y = zeros(1,cols);
    theta1_values = zeros(1,cols);          % Array storing the degree values of angle Theta1
    theta2_values = zeros(1,cols);          % Array storing the degree values of angle Theta2
    
    for i = 1:1:cols          % For loop to create the circular trajectory in 37 points
        v = v + 1;
        
        % Desired cicular trajectory
        Px = tibia_x_fit(1,i);           % x coordinates of the end of the robot (P) corresponding to each iteration
        Py = tibia_y_fit(1,i);           % y coordinates of the end of the robot (P) corresponding to each iteration
        
        % Reverse cinematic model use to determine the angles Theta1 y Theta2
        k = (Px^2 + Py^2 - l1^2 - l2^2)/(2*l1*l2);

        theta2 = acos(k);
        theta2_deg = acosd(k);
        theta2_values(v) = theta2_deg;          % Theta2 storage


        gamma = atan2(Py, Px);
        alpha = atan2(l2*sin(theta2), (l1+l2*cos(theta2)));
        theta1 = gamma - alpha;
        theta1_deg = rad2deg(theta1);           % Conversion from radian to degrees
        theta01 = 90 - abs(theta1_deg);         % In our kinematic diagram, the angle Theta1 corresponds to the angle between the y-axis and bar1 or until now we calculated the angle between the x-axis and bar 1
        theta1_values(v) = theta01;             % Theta1 storage
        
        % Conversion of theta1 to theta1_motor
        D1 = 26.42;            % Small pulley diameter in mm
        D1_motor = 18.06;      % Motor diameter in mm
        R = D1/D1_motor; 
        theta01_motor = R*theta01;
        theta1_motor(v) = theta01_motor;
    
        % 4-bars linkage mechanism
        phi2 = theta2_deg -9.21;
        phi2t(v) = phi2;
        AC = sqrt(OA^2+OC^2-2*OC*OA*cosd(phi2));

        alpha1 = acosd((AC^2+AB^2-BC^2)/(2*AC*AB));

        if 0 < phi2 && phi2 < 180
            beta1 = alpha1 + acosd((OA^2+AC^2-OC^2)/(2*OA*AC));
        else
            beta1 = alpha1 - acosd((OA^2+AC^2-OC^2)/(2*OA*AC));
        end

        gamma = acosd((AB^2+BC^2-AC^2)/(2*AB*BC));

        phi4 = phi2 + beta1 + gamma -180 + 9.21;
        phi4t(v) = phi4;
        D2 = 26.42;            % Small pulley diameter in mm
        D2_motor = 26.42;      % Motor diameter in mm
        R = D2/D2_motor; 
        theta02_motor = R*phi4;
        theta2_motor(v) = theta02_motor; % result
    end

    theta1_motor = theta1_motor(:);
    theta2_motor = theta2_motor(:);
    t1 = t1(:);
    p01 = polyfit(t1,theta1_motor,10);
    coef_motor1 = p01;
    p01_fit = polyval(p01, t1);
    
    t1=t1(:);
    p02 = polyfit(t1,theta2_motor,10);
    coef_motor2 = p02;
    p02_fit = polyval(p02, t1);

    p001 = polyfit(t1,theta1_values,5);
    p002 = polyfit(t1,phi4t,5);
    envioRaspi(coef_motor1, coef_motor2, t_total)
end
