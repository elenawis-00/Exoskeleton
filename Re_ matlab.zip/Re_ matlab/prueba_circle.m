function [tobillo_x, tobillo_y] = prueba_circle(l1, l2, g, m1, m2, OA, AB, BC, OC);
% Determination of the Theta1 and Theta2 angles of the EXOLEG (in degrees), according to a trajectory imposed at point P (end of the robot)

beta = linspace(0, 2*pi, 37);           % Increment of circle path points
v = 0;
vPx = zeros;            % Array storing the x coordinates of the desired trajectory
vPy = zeros;            % Array storing the y coordinates of the desired trajectory
X = zeros;
Y = zeros;
theta1_values = zeros;          % Array storing the degree values of angle Theta1
theta2_values = zeros;          % Array storing the degree values of angle Theta2


for i = 1:1:37          % For loop to create the circular trajectory in 37 points
    v = v + 1;
    
    % Desired cicular trajectory
    cx = 350;           % x coordinates of the center of the desired cercle
    cy = -350;          % y coordinates of the center of the desired cercle
    r = 100;             % Radius of the desired circle
    Px = cx + r*cos(beta(i));           % x coordinates of the end of the robot (P) corresponding to each iteration
    Py = cy + r*sin(beta(i));           % y coordinates of the end of the robot (P) corresponding to each iteration
    tobillo_x(v) = Px;
    tobillo_y(v) = Py;
  
end