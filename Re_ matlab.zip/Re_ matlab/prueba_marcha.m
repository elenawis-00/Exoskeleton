%VOY a cargar los datos del subject 2, habiendo hecho la media de todas las
%repeticiones, ya que cogiendo la media de todos los subjects había mucha
%variacion en la trayaectoria porque habia variacion en los dtaos de su
%femur y tibaia apor lo que los angulos fde flexo-extension no tenian los
%valores que se representa en al teoria por la variacion de datos 
% Leer los datos del archivo de la cadera

%tengo unos datos para un t=1, me gustaria poder visualizar esos datos para
%un t = lo que quiera el usuario. Si el usuario quiere un t<1 habra que
%comprimir los datos, y su t>1 tendran que expandirse, de manera que si
%t=3, los angulos de flexoextension tengan en t=3 el valor correspondiente
%a t=1 y en t = 1.5 el valor correspondiente a t=0.5. 


%busca una funcion que alise la ultima parte del moviiento de la marcha,
%(las condicione sde finalizacion tienen que ser ==) 
%EVALUA EL POLINOMIO CON LAS OCNDICCIONES DE QUE SEA IGUAL AL INICIO Y AL
%FINAL
function [tobillo_x, tobillo_y] = prueba_marcha(l1, l2, g, m1, m2, OA, AB, BC, OC);
% Leer los datos del archivo de la cadera
angulos_cadera = load('cadera_adulto_pierna1.txt');

% Leer los datos del archivo de la rodilla
angulos_rodilla = load('rodilla_adulto_pierna1.txt');

% Insertar el tiempo que quiere visualizar (en segundos)
t = duration; 

% Los valores estándar de fémur y tibia, según https://www.ucm.es/data/cont/docs/420-2014-02-18-01%20fisiopatologia%20osea.pdf

altura_media_nino = 1.38; % Estatura media en metros
variacion_altura = 0.085; % Variación de +/- 8.5 cm

% Solicitar al usuario la altura del paciente
altura_paciente = 1.4;

% Calcular las longitudes del fémur y la tibia en función de la altura del paciente
femur = 0.2674 * altura_paciente; % https://es.wikipedia.org/wiki/F%C3%A9mur
tibia = 0.17 * altura_paciente; % La tibia ocupa aproximadamente el 17% de la altura del cuerpo humano

% Inicializar vectores de posición
cadera_x = zeros(1, length(angulos_cadera)); % La cadera es fija en x=0
cadera_y = ones(1, length(angulos_cadera)); % La cadera es fija en y=1
rodilla_x = zeros(1, length(angulos_cadera));
rodilla_y = zeros(1, length(angulos_cadera));
tobillo_x = zeros(1, length(angulos_cadera));
tobillo_y = zeros(1, length(angulos_cadera));

% Calcular las posiciones de la rodilla y el tobillo
for i = 1:length(angulos_cadera)
    % Posición de la cadera (fija)
    cadera_x(i) = 0;
    cadera_y(i) = 1;
    
    % Posición de la rodilla
    rodilla_x(i) = cadera_x(i) + femur * sin(angulos_cadera(i));
    rodilla_y(i) = cadera_y(i) - femur * cos(angulos_cadera(i));
    
    % Posición del tobillo
    tobillo_x(i) = rodilla_x(i) + tibia * sin(angulos_rodilla(i));
    tobillo_y(i) = rodilla_y(i) - tibia * cos(angulos_rodilla(i));
end

% Crear una figura para la animación
figure;
hold on;
axis equal;
axis([-1 1 -1 2]);
xlabel('Posición en X (m)');
ylabel('Posición en Y (m)');
title('Ciclo Completo Pierna Izquierda, Altura Estándar 10 años');

% Inicializar la trayectoria de la cadera, rodilla y tobillo
cadera_traj = plot(cadera_x(1), cadera_y(1), 'ro', 'MarkerFaceColor', 'r');
rodilla_traj = plot(rodilla_x(1), rodilla_y(1), 'go', 'MarkerFaceColor', 'g');
tobillo_traj = plot(tobillo_x(1), tobillo_y(1), 'bo', 'MarkerFaceColor', 'b');

% Dibujar la trayectoria del fémur (morado) y la tibia (negro) como palos
for i = 1:length(angulos_cadera)
    % Dibujar el fémur
    plot([cadera_x(i), rodilla_x(i)], [cadera_y(i), rodilla_y(i)], 'm', 'LineWidth', 2);
    % Dibujar la tibia
    plot([rodilla_x(i), tobillo_x(i)], [rodilla_y(i), tobillo_y(i)], 'k', 'LineWidth', 2);
    pause(0.05); % Pausa de 0.05 segundos para la animación
    
    % Actualizar la trayectoria de la cadera, rodilla y tobillo
    set(cadera_traj, 'XData', cadera_x(1:i), 'YData', cadera_y(1:i));
    set(rodilla_traj, 'XData', rodilla_x(1:i), 'YData', rodilla_y(1:i));
    set(tobillo_traj, 'XData', tobillo_x(1:i), 'YData', tobillo_y(1:i));
end
% Añadir la leyenda
legend({'Cadera', 'Rodilla', 'Tobillo', 'Fémur (morado)', 'Tibia (negro)'}, 'Location', 'Best');
    tobillo_x = tobillo_x*1000+200;
    tobillo_y = tobillo_y*1000-900;