function [tobillo_x, tobillo_y] = prueba_rectangle(l1, l2, g, m1, m2, OA, AB, BC, OC);

% Determination of the Theta1 and Theta2 angles of the EXOLEG (in degrees), according to a trajectory imposed at point P (end of the robot)

v = 0;
vPx = zeros;            % Array storing the x coordinates of the desired trajectory
vPy = zeros;            % Array storing the y coordinates of the desired trajectory
X = zeros;
Y = zeros;
theta1_values = zeros(1,100);          % Array storing the degree values of angle Theta1
theta2_values = zeros(1,100);          % Array storing the degree values of angle Theta2
Px = zeros(1,100);
Py = zeros(1,100);

Px_start = 350;
Py_start = -350;
side_length = 150;
num_points_per_side = 25;


for i = 1:1:100          % For loop to create the circular trajectory in 37 points
    v = v + 1;
    
    cx = Px_start;           % x coordinates of the center of the desired cercle
    cy = Py_start;           % y coordinates of the center of the desired cercle

    if i>=1 && i<=101/4
            % Desired cicular trajectory
            Px(i) = cx + (i)*side_length/num_points_per_side;           % x coordinates of the end of the robot (P) corresponding to each iteration
            Py(i) = cy;                                                   % y coordinates of the end of the robot (P) corresponding to each iteration

    elseif i>41/4 && i<=2*101/4
                % Desired Trajectory
                Px(i) = cx + side_length;
                Py(i) = cy + (i-25)*side_length/num_points_per_side;

    elseif i>2*41/4 && i<=3*101/4
            % Desired Trajectory
            Px(i) = cx + side_length - (i-2*25)*side_length/num_points_per_side;
            Py(i) = cy + side_length;

    elseif i>3*41/4 && i<=4*100/4
        % Desired Trajectory
        Px(i) = cx;
        Py(i) = cy + side_length - (i-3*25)*side_length/num_points_per_side;

    end

    % Storing values in corresponding tables
    vPx(v) = Px(i);
    vPy(v) = Py(i);
    tobillo_x(v) = Px(i);
    tobillo_y(v) = Py(i);
end

    