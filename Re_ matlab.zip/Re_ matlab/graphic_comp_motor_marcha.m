function fig3 = graphic_comp_motor_marcha(t_total, theta1_motor, theta2_motor,tobillo_x, tobillo_y, l1, l2, g, m1, m2, OA, AB, BC, OC);

% Determination of the Theta1 and Theta2 angles of the EXOLEG (in degrees), according to a trajectory imposed at point P (end of the robot)

v = 0;

tibia_pos_x = tobillo_x;
tibia_pos_y = tobillo_y;

[n, m] = size(tobillo_x);
[n2, m2] = size(theta1_motor);

vPx = zeros(1, m);            % Array storing the x coordinates of the desired trajectory
vPy = zeros(1,m);            % Array storing the y coordinates of the desired trajectory
X = zeros(1,m);
Y = zeros(1,m);
theta1_values = zeros(1,m);          % Array storing the degree values of angle Theta1
theta2_values = zeros(1,m);          % Array storing the degree values of angle Theta2

theta1_motor_elena = theta1_motor;
theta2_motor_elena = theta2_motor;
% 
% tibia_pos_x = tobillo_x;
% tibia_pos_y = tobillo_y;

for i = 1:1:m          % For loop to create the circular trajectory in 37 points
    v = v + 1;
    
    % Desired cicular trajectory
    Px = tibia_pos_x(1,i);           % x coordinates of the end of the robot (P) corresponding to each iteration
    Py = tibia_pos_y(1,i);           % y coordinates of the end of the robot (P) corresponding to each iteration
    
    % Reverse cinematic model use to determine the angles Theta1 y Theta2
    k = (Px^2 + Py^2 - l1^2 - l2^2)/(2*l1*l2);
    theta2 = acos(k);
    theta2_deg = rad2deg(theta2);           % Conversion from radian to degrees
    theta2_values(v) = theta2_deg;          % Theta2 storage
   
    gamma = atan2(Py, Px);
    alpha = atan2(l2*sin(theta2), (l1+l2*cos(theta2)));
    theta1 = gamma - alpha;
    theta1_deg = rad2deg(theta1);           % Conversion from radian to degrees
    theta01 = 90 - abs(theta1_deg);         % In our kinematic diagram, the angle Theta1 corresponds to the angle between the y-axis and bar1 or until now we calculated the angle between the x-axis and bar 1
    theta1_values(v) = theta01;             % Theta1 storage
    
    % Conversion of theta1 to theta1_motor
    D1 = 26.42;            % Small pulley diameter in mm
    D1_motor = 18.06;      % Motor diameter in mm
    R = D1/D1_motor; 
    theta01_motor = R*theta01;
    theta1_motor(v) = theta01_motor;

    % 4-bars linkage mechanism
    phi2 = theta2_deg -9.21;
    phi2t(v) = phi2;
    AC = sqrt(OA^2+OC^2-2*OC*OA*cosd(phi2));
    alpha1 = acosd((AC^2+AB^2-BC^2)/(2*AC*AB));

    if 0 < phi2 && phi2 < 180
        beta1 = alpha1 + acosd((OA^2+AC^2-OC^2)/(2*OA*AC));
    else
        beta1 = alpha1 - acosd((OA^2+AC^2-OC^2)/(2*OA*AC));
    end

    gamma = acosd((AB^2+BC^2-AC^2)/(2*AB*BC));

    phi4 = phi2 + beta1 + gamma -180 + 9.21 ;
    phi4t(v) = phi4;
    D2 = 26.42;            % Small pulley diameter in mm
    D2_motor = 26.42;      % Motor diameter in mm
    R = D2/D2_motor; 
    theta02_motor = R*phi4;
    theta2_motor(v) = theta02_motor; % result
    vPx(v) = Px;
    vPy(v) = Py;
end
v=0;
for i = 1:1:m2
    v = v + 1;

    %
       if 180 < theta1_motor_elena(1,v)
        theta1_motor_elena(1,v) = - 360 + theta1_motor_elena(1,v);
    end

    % Conversion of theta1-motor to theta1
    D1 = 26.42;            % Small pulley diameter in mm
    D1_motor = 18.06;      % Motor diameter in mm
    R = D1/D1_motor; 
    theta01_motor = theta1_motor_elena(1,v);
    theta01 = theta01_motor/R;
    theta01_t(v) = theta01;

    % 4-bars linkage mechanism
    D2 = 26.42;            % Small pulley diameter in mm
    D2_motor = 26.42;      % Motor diameter in mm
    R = D2/D2_motor; 
    theta02_motor = theta2_motor_elena(1,v);
    phi4_d = theta02_motor/R;
    phi4t(1,v) = phi4_d;

    phi04 = 180 - phi4_d + 9.21;
    phi04t(v) = phi04;

  
    OB = sqrt(BC^2 + OC^2 - 2*OC*BC*cosd(phi04));
    alpha1 = acosd((OB^2 + AB^2 - OA^2)/(2*OB*AB));

  if 0 < phi04 && phi04 < 180
        beta1 = alpha1 + acosd((BC^2+OB^2-OC^2)/(2*BC*OB));
    else
        beta1 = alpha1 - acosd((BC^2+OB^2-OC^2)/(2*BC*OB));
    end

    gamma = acosd((AB^2 + OA^2 - OB^2)/(2*AB*OA));


    phi2 = phi04 + beta1 + gamma - 180;
    phi2t(v) = phi2;

    theta2_deg = 180 - phi2 + 9.21;
    theta2 = deg2rad(theta2_deg);

    theta1_deg = -(90 - theta01);
    theta1 = deg2rad(theta1_deg);
    theta1t(1,v) = theta1_deg;

    % Direct cinematic model allowing to check if the angles found achieve the desired trajectory
    A01 = [cos(theta1) -sin(theta1) 0 l1*cos(theta1); sin(theta1) cos(theta1) 0 l1*sin(theta1); 0 0 1 0; 0 0 0 1];
    A12 = [cos(theta2) -sin(theta2) 0 l2*cos(theta2); sin(theta2) cos(theta2) 0 l2*sin(theta2); 0 0 1 0; 0 0 0 1];
    A02 = A01*A12;

    % Storing values in corresponding tables
    X(v) = A02(1,4);
    Y(v) = A02(2,4);
    
end

% Graphic animation of the EXOLEG
    fig3 = figure;
    plot([0,A01(1,4)],[0,A01(2,4)],'-b',...                         % Graphical representation of the bar1
         [A01(1,4),A02(1,4)],[A01(2,4),A02(2,4)],'-b',...           % Graphical representation of the bar1
         0,0,'ob',...                                               % Articulation1
         A01(1,4),A01(2,4),'ob')                                    % Articulation2
    hold on;

    plot(vPx,vPy,'og',...                                           % Graphical representation of the desired trajectory
         'DisplayName', 'Desired trajectory');
    hold on;

    plot(X,Y,'.b', 'DisplayName','Carried out trajectory');           % Graphical representation of the trajectory carried out
    hold off;

    axis([-100 450 -650 100]);
    legend('','','','','Desired trajectory','Carried out trajectory');
    axis equal

    text(-20,0,'A');
    text(A01(1,4)+10,A01(2,4),'B');
    text(A02(1,4)+10,A02(2,4),'P');

    xlabel('x (mm)');
    ylabel('y (mm)');
    title('Graphic animation of the EXOLEG');
    grid on;
    grid minor;
