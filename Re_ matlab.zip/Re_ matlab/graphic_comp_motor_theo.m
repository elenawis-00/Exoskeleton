function fig2 = graphic_comp_motor_theo(t_total, theta1_motor, theta2_motor, coef_motor1, coef_motor2, l1, l2, g, m1, m2, OA, AB, BC, OC);

% Determination of the Theta1 and Theta2 angles of the EXOLEG (in degrees), according to a trajectory imposed at point P (end of the robot)

[n, m] = size(theta1_motor);

v = 0;
t = 0.1:0.1:t_total;
t = t(:);

p = t_total/m;

t1 = 0:p:t_total;
x = linspace(p,t_total,m);
theta1m_d = polyval(coef_motor1,x);
theta2m_d = polyval(coef_motor2,x);

vPx = zeros(1, m);            % Array storing the x coordinates of the desired trajectory
vPy = zeros(1,m);            % Array storing the y coordinates of the desired trajectory
X = zeros(1,m);
Y = zeros(1,m);
theta1_values = zeros(1,m);          % Array storing the degree values of angle Theta1
theta2_values = zeros(1,m);          % Array storing the degree values of angle Theta2theta01_t = zeros(1,200);
theta01_t = zeros(1,m);

for i = 1:1:m
    v = v + 1;
    theta1_motor_d(v) = theta1m_d(i);
    theta2_motor_d(v) = theta2m_d(i);
        %Direct kinematic
        if 180 < theta1_motor_d(1,v)
        theta1_motor_d(1,v) = - 360 + theta1_motor_d(1,v);
    end

    % Conversion of theta1-motor to theta1
    D1 = 26.42;            % Small pulley diameter in mm
    D1_motor = 18.06;      % Motor diameter in mm
    R = D1/D1_motor; 
    theta01_motor_d = theta1_motor_d(1,v);
    theta01_d = theta01_motor_d/R;
    theta01_t_d(v) = theta01_d;

    % 4-bars linkage mechanism
    D2 = 26.42;            % Small pulley diameter in mm
    D2_motor = 26.42;      % Motor diameter in mm
    R = D2/D2_motor; 
    theta02_motor_d = theta2_motor_d(1,v);
    phi4_d = theta02_motor_d/R;
    phi4t_d(1,v) = phi4_d;

    phi04_d = 180 - phi4_d + 9.21;
    phi04t_d(v) = phi04_d;

  
    OB = sqrt(BC^2 + OC^2 - 2*OC*BC*cosd(phi04_d));
    alpha1 = acosd((OB^2 + AB^2 - OA^2)/(2*OB*AB));

  if 0 < phi04_d && phi04_d < 180
        beta1 = alpha1 + acosd((BC^2+OB^2-OC^2)/(2*BC*OB));
    else
        beta1 = alpha1 - acosd((BC^2+OB^2-OC^2)/(2*BC*OB));
    end

    gamma = acosd((AB^2 + OA^2 - OB^2)/(2*AB*OA));


    phi2_d = phi04_d + beta1 + gamma - 180;
    phi2t_d(v) = phi2_d;

    theta2_deg_d = 180 - phi2_d + 9.21;
    theta2_d = deg2rad(theta2_deg_d);

    theta1_deg_d = -(90 - theta01_d);
    theta1_d = deg2rad(theta1_deg_d);
    theta1t_d(1,v) = theta1_deg_d;


  % Direct cinematic model allowing to check if the angles found achieve the desired trajectory
    A01_th = [cos(theta1_d) -sin(theta1_d) 0 l1*cos(theta1_d); sin(theta1_d) cos(theta1_d) 0 l1*sin(theta1_d); 0 0 1 0; 0 0 0 1];
    A12_th = [cos(theta2_d) -sin(theta2_d) 0 l2*cos(theta2_d); sin(theta2_d) cos(theta2_d) 0 l2*sin(theta2_d); 0 0 1 0; 0 0 0 1];
    A02_th = A01_th*A12_th;

     % Desired marcha trajectory
    Px_th = A02_th(1,4);           % x coordinates of the end of the robot (P) corresponding to each iteration
    Py_th = A02_th(2,4);           % y coordinates of the end of the robot (P) corresponding to each iteration
    

    % Storing values in corresponding tables
    vPx(v) = Px_th;
    vPy(v) = Py_th;
  
    if 180 < theta1_motor(1,v)
        theta1_motor(1,v) = - 360 + theta1_motor(1,v);
    end

    % Conversion of theta1-motor to theta1
    D1 = 26.42;            % Small pulley diameter in mm
    D1_motor = 18.06;      % Motor diameter in mm
    R = D1/D1_motor; 
    theta01_motor = theta1_motor(1,v);
    theta01 = theta01_motor/R;
    theta01_t(v) = theta01;

    % 4-bars linkage mechanism
    D2 = 26.42;            % Small pulley diameter in mm
    D2_motor = 26.42;      % Motor diameter in mm
    R = D2/D2_motor; 
    theta02_motor = theta2_motor(1,v);
    phi4 = theta02_motor/R;
    phi4t(1,v) = phi4;

    phi04 = 180 - phi4 + 9.21;
    phi04t(v) = phi04;

  
    OB = sqrt(BC^2 + OC^2 - 2*OC*BC*cosd(phi04));
    alpha1 = acosd((OB^2 + AB^2 - OA^2)/(2*OB*AB));

  if 0 < phi04 && phi04 < 180
        beta1 = alpha1 + acosd((BC^2+OB^2-OC^2)/(2*BC*OB));
    else
        beta1 = alpha1 - acosd((BC^2+OB^2-OC^2)/(2*BC*OB));
    end

    gamma = acosd((AB^2 + OA^2 - OB^2)/(2*AB*OA));


    phi2 = phi04 + beta1 + gamma - 180;
    phi2t(v) = phi2;

    theta2_deg = 180 - phi2 + 9.21;
    theta2 = deg2rad(theta2_deg);

    theta1_deg = -(90 - theta01);
    theta1 = deg2rad(theta1_deg);
    theta1t(1,v) = theta1_deg;

    % Direct cinematic model allowing to check if the angles found achieve the desired trajectory
    A01 = [cos(theta1) -sin(theta1) 0 l1*cos(theta1); sin(theta1) cos(theta1) 0 l1*sin(theta1); 0 0 1 0; 0 0 0 1];
    A12 = [cos(theta2) -sin(theta2) 0 l2*cos(theta2); sin(theta2) cos(theta2) 0 l2*sin(theta2); 0 0 1 0; 0 0 0 1];
    A02 = A01*A12;

    % Storing values in corresponding tables
    X(v) = A02(1,4);
    Y(v) = A02(2,4);
end
    % Graphic animation of the EXOLEG
    fig2 = figure;
    plot([0,A01(1,4)],[0,A01(2,4)],'-b',...                         % Graphical representation of the bar1
         [A01(1,4),A02(1,4)],[A01(2,4),A02(2,4)],'-b',...           % Graphical representation of the bar1
         0,0,'ob',...                                               % Articulation1
         A01(1,4),A01(2,4),'ob')                                    % Articulation2
    hold on;

    plot(vPx,vPy,'.r',...                                           % Graphical representation of the desired trajectory
         'DisplayName', 'Theorical Trajectory');
    hold on;

    plot(X,Y,'.b', 'DisplayName','Carried out trajectory');           % Graphical representation of the trajectory carried out
    hold off;

    axis([-100 450 -650 100]);
    legend('','','','','Theorical Trajectory','Carried out trajectory');
    axis equal
    
    text(-20,0,'A');
    text(A01(1,4)+10,A01(2,4),'B');
    text(A02(1,4)+10,A02(2,4),'P');

    xlabel('x (mm)');
    ylabel('y (mm)');
    title('Graphic animation of the EXOLEG');
    grid on;
    grid minor;
