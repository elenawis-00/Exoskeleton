from carpeta_exo.srv import mensaje_odrive

import rclpy
from rclpy.node import Node



class Service(Node):

    def __init__(self):
        super().__init__('servicio')
        self.srv = self.sreate_service(mensaje_odrive, 'mensaje_pos_odrive', self.posiciones_callback)


    def posiciones_callback(self, request, response):

        if request.tipo_envio=='1':
            if request.trayectoria_seguida=='1':
                response.posiciones='1.1'
            if request.trayectoria_seguida=='2':
                response.posiciones='1.2'
            if request.trayectoria_seguida=='3':
                response.posiciones='1.3'

        if request.tipo_envio=='2':
            response.posiciones='2.05'

        self.get_logger().info('Tipo de envio: %d \nTrayectoria: %d' % (request.tipo_envio, request.trayectoria_seguida))
        




def main(args=None):

    rclpy.iniy(args=args)

    servicio=Servicio()
    rclpy.spin(servicio)
    rclpy.shutdown()


if __name__=='__main__':
    main()




