import os
import sys
from pathlib import Path



package_name='py_srvcli'
srv_dir=Path(__file__).parent / 'srv'
output_dir = Path(__file__).parent / 'generated'

os.system(f'ros2 interface generate --package {package_name} --srv {srv_dir} --output {output_dir}')
