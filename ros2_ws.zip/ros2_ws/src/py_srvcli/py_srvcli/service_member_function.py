from example_interfaces.srv import AddTwoInts

import rclpy
from rclpy.node import Node


class Service(Node):

    def __init__(self):
        super().__init__('servicio')
        self.srv = self.create_service(AddTwoInts, 'mensaje_pos_odrive', self.posiciones_callback)


    def posiciones_callback(self, request, response):

        if request.a=='1':
            if request.b=='1':
                response.sum='1.1'
            if request.b=='2':
                response.sum='1.2'
            if request.b=='3':
                response.sum='1.3'

        if request.a=='2':
            response.sum='2.05'

        self.get_logger().info('Tipo de envio: %d \nTrayectoria: %d' % (request.a, request.b))
        




def main(args=None):

    rclpy.init(args=args)

    servicio=Service()
    rclpy.spin(servicio)
    rclpy.shutdown()


if __name__=='__main__':
    main()


