import sys

from example_interfaces.srv import ejemplo
import rclpy
from rclpy.node import Node

tray=0
envi=0



class Client(Node):

    def __init__(self):
        super().__init__('cliente')
        self.cli = self.create_client(ejemplo,'mensaje_pos_odrive')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.req=ejemplo.Request()

    def send_request(self, tipo_envio, trayectoria_seguida):
        global tray, envi

        print("¿Quiere elegir una trayectoria manualmente o enviarla desde otra terminal?")
        print("1.Elegir manualmente")
        print("2.Enviarla")

      #  self.req.tipo_envio=input("Seleccione una opción (1-2): ")
        envi=input("Seleccione una opción (1-2): ")
        self.req.a=int(envi)
        print("\n")

        print("Elija un tipo de rehabilitación")
        print("1.Círculo")
        print("2.Cuadrado")
        print("3.Marcha")
        tray=input("Seleccione una opción (1-3): ")
        self.req.b=int(tray)

        self.future = self.cli.call_async(self.req)
        rclpy.spin_until_future_complete(self, self.future)
        return self.future.results()


def main(args=None):
    global tray, envi
        
    rclpy.init(args=args)
    
    cliente=Client()
    response=cliente.send_request(int(envi), int(tray))
    cliente.get_logger().info(
        'Envio elegido: %d con trayectoria: %d da la siguiente posicion= %d' %
        (int(sys.argv[1]), int(sys.argv[2]), response.posiciones)
    )

    cliente.destroy_node()
    rclpy.shutdown()




if __name__ == '__main__':
    main()











