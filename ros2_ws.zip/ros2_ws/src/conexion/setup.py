from setuptools import setup

package_name = 'conexion'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    py_modules=[
        'conexion.input_node_exo',
        'conexion.output_node_exo',
    ],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/msg', ['msg/Posiciones.msg']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='ubuntu@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'input_node=conexion.input_node_exo:main',
            'output_node=conexion.output_node_exo:main',
        ],
    },
)
